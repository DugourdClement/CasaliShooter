var searchData=
[
  ['vecmug',['vecMug',['../structmug_struct.html#a2bc7388cc3e5932a8a5e76f63658e4fc',1,'mugStruct']]],
  ['vecsprite',['vecSprite',['../structenemy_struct.html#a88efe046686ad9ecc0e60e5aabc282b2',1,'enemyStruct::vecSprite()'],['../structenemy.html#a5d5bfc2d5a66dadb5e023e719f0af31d',1,'enemy::vecSprite()']]]
];
