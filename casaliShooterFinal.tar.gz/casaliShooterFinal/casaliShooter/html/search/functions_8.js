var searchData=
[
  ['lightordark',['LightOrDark',['../menu_8cpp.html#a6c0c0e99cc747b21773b1c067763b4f3',1,'LightOrDark(MinGL &amp;window, unsigned &amp;choiceObject, Sprite &amp;themelight, Sprite &amp;themedark):&#160;menu.cpp'],['../menu_8h.html#ae21d55135ac8d20b9a80974ea7304ad2',1,'LightOrDark(MinGL &amp;, unsigned &amp;, nsGui::Sprite &amp;, nsGui::Sprite &amp;):&#160;menu.h']]]
];
