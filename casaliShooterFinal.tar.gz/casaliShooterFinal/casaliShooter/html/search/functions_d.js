var searchData=
[
  ['scoreb',['scoreb',['../main_8cpp.html#ade17072f655da9a6955c325726eab641',1,'main.cpp']]],
  ['scoreboardbg',['scoreboardbg',['../main_8cpp.html#a1359085ab1529045fb9a7092dea9a8ce',1,'main.cpp']]],
  ['selecttheme',['selectTheme',['../menu_8cpp.html#a3f44b1c0ce154f89859f80d018ebbf9f',1,'selectTheme(MinGL &amp;window, Sprite &amp;image, vector&lt; unsigned &gt; vecKey):&#160;menu.cpp'],['../menu_8h.html#a04bf1e96a21258789d53a360d756b55f',1,'selectTheme(MinGL &amp;, nsGui::Sprite &amp;, std::vector&lt; unsigned &gt;):&#160;menu.h']]],
  ['settingsb',['settingsb',['../main_8cpp.html#a470e58be39d5499c5618e545089519cb',1,'main.cpp']]],
  ['setvalues',['setValues',['../class_bg_text.html#adb35c1e7e0387e04e8f8e67d9e1468c8',1,'BgText']]],
  ['showscore',['showScore',['../menu_8cpp.html#aa1e161f3088f4cdb58256e456a354529',1,'showScore(MinGL &amp;window):&#160;menu.cpp'],['../menu_8h.html#a5f9104235ab4378026f1877302915f2a',1,'showScore(MinGL &amp;):&#160;menu.cpp']]],
  ['startb',['startb',['../main_8cpp.html#a0e90fe491ef79dc658553bf693936497',1,'main.cpp']]],
  ['sun',['sun',['../main_8cpp.html#a89151110665c55891fa9a85f73c48b32',1,'main.cpp']]]
];
