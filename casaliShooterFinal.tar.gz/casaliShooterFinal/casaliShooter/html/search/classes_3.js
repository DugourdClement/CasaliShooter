var searchData=
[
  ['players',['players',['../structplayers.html',1,'']]],
  ['playersstruct',['playersStruct',['../structplayers_struct.html',1,'']]]
];
