var searchData=
[
  ['mugstruct',['mugStruct',['../structmug_struct.html',1,'']]]
];
