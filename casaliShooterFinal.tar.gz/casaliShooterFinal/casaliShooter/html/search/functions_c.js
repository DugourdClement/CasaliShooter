var searchData=
[
  ['reset',['reset',['../main_8cpp.html#a7064cf1480273ddc71d2e645f630d736',1,'main.cpp']]]
];
