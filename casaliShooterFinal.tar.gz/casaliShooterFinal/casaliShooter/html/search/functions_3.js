var searchData=
[
  ['display',['display',['../main_8cpp.html#a20a4bb80f5bbf5080d834aa23b941e31',1,'main.cpp']]],
  ['draw',['draw',['../class_bg_text.html#a01df624a8d498766a9eb579eb18f2326',1,'BgText']]]
];
