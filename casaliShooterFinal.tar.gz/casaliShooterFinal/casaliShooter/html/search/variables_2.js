var searchData=
[
  ['rightorleft',['rightOrLeft',['../structenemy_struct.html#aa320b69ab30afa4769df38330c1b6012',1,'enemyStruct::rightOrLeft()'],['../structenemy.html#a7dead7d7d9264186d09eb3c5ef36689d',1,'enemy::rightOrLeft()']]]
];
