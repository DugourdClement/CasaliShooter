var searchData=
[
  ['bgtext_2ecpp',['bgtext.cpp',['../bgtext_8cpp.html',1,'']]],
  ['bgtext_2eh',['bgtext.h',['../bgtext_8h.html',1,'']]]
];
