var searchData=
[
  ['ovnishoot',['ovniShoot',['../check_8cpp.html#adbc27b43e253be2a4e0495914e32ad2f',1,'ovniShoot(mugStruct &amp;mug, enemyStruct &amp;ovni, bool &amp;ovniShootT, Vec2D &amp;posTorOvni):&#160;check.cpp'],['../check_8h.html#aa65794beee7d3236ed4cd814c07146e7',1,'ovniShoot(mugStruct &amp;, enemyStruct &amp;, bool &amp;, nsGraphics::Vec2D &amp;):&#160;check.h']]]
];
