var searchData=
[
  ['keyboard',['keyboard',['../move_8cpp.html#aedafca61ffb966200cc47db9fd8acf20',1,'keyboard(MinGL &amp;window, Sprite &amp;mug, vector&lt; unsigned &gt; vecKey):&#160;move.cpp'],['../move_8h.html#a7861fbf31a5ed036ae380239481ddbae',1,'keyboard(MinGL &amp;, nsGui::Sprite &amp;, std::vector&lt; unsigned &gt;):&#160;move.h']]],
  ['keyboardwrite',['keyboardWrite',['../main_8cpp.html#a2e5a554f274b4d74ea0473b2d05a51d0',1,'main.cpp']]]
];
