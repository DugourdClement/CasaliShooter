var searchData=
[
  ['casali',['casali',['../main_8cpp.html#a374beb5a2144b13bc345cfceb8e6022e',1,'main.cpp']]],
  ['choosetheme',['chooseTheme',['../menu_8cpp.html#ad71a4270e525386f9fb5ac4550889d9d',1,'chooseTheme(MinGL &amp;window, Sprite &amp;image, unsigned &amp;baseTheme, vector&lt; unsigned &gt; vecKey):&#160;menu.cpp'],['../menu_8h.html#a174592747469d4f6a1ff3aa11d98463d',1,'chooseTheme(MinGL &amp;, nsGui::Sprite &amp;, unsigned &amp;, std::vector&lt; unsigned &gt;):&#160;menu.h']]],
  ['colision',['colision',['../check_8cpp.html#a0387a207541d2bf09208d5a8fb73bc0a',1,'colision(const Vec2D misPos, enemyStruct &amp;vecSprite):&#160;check.cpp'],['../check_8h.html#a94d65c5e06209ea6bba18c9ac85385e4',1,'colision(const nsGraphics::Vec2D, enemyStruct &amp;):&#160;check.h']]],
  ['credit',['credit',['../menu_8cpp.html#a09f173a92886abe0873d0da71ab792f4',1,'credit(MinGL &amp;window, Sprite &amp;backgroundNoScreen, Sprite &amp;creditSprite):&#160;menu.cpp'],['../menu_8h.html#a825abbcbdb39c77b9815e9796edede8e',1,'credit(MinGL &amp;, nsGui::Sprite &amp;, nsGui::Sprite &amp;):&#160;menu.h']]],
  ['creditsprite',['creditSprite',['../main_8cpp.html#ae00166a9de9b69d22aa6663655e9172a',1,'main.cpp']]]
];
