var searchData=
[
  ['isbetter',['isBetter',['../menu_8cpp.html#ab5e934d2ef49bd2e67f1e9c09a419bf0',1,'isBetter(const playersStruct &amp;joueur1, const playersStruct &amp;joueur2):&#160;menu.cpp'],['../menu_8h.html#aa3042991daf1e6f41437ddcb9d7a046c',1,'isBetter(const playersStruct &amp;, const playersStruct &amp;):&#160;menu.cpp']]],
  ['istouching',['isTouching',['../check_8cpp.html#a64f0a4dbed107e0b38ab5bc43e318e1d',1,'isTouching(const Vec2D firstCorner, const Vec2D secondCorner, const Vec2D test):&#160;check.cpp'],['../check_8h.html#a2a2d83dde2e005fc42c9faf97421f419',1,'isTouching(const nsGraphics::Vec2D, const nsGraphics::Vec2D, const nsGraphics::Vec2D):&#160;check.h']]]
];
