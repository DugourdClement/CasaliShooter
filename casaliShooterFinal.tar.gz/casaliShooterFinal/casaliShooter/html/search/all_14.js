var searchData=
[
  ['_7ebgtext',['~BgText',['../class_bg_text.html#a19f8e1aa743e37d252b5b46ca98b7cd1',1,'BgText']]]
];
