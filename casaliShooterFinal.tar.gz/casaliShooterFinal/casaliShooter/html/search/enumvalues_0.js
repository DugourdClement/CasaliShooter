var searchData=
[
  ['transition_5fbackground_5fcolor',['TRANSITION_BACKGROUND_COLOR',['../class_bg_text.html#a5599f62d188a03c0bf5b51bb71f0ee95a312ae9c6f63f2076bd975b165167c8e1',1,'BgText']]],
  ['transition_5ftext_5fcolor',['TRANSITION_TEXT_COLOR',['../class_bg_text.html#a5599f62d188a03c0bf5b51bb71f0ee95ac6cb4dc038246ac7206356a76bbdd1e3',1,'BgText']]]
];
