var searchData=
[
  ['quitb',['quitb',['../main_8cpp.html#a84283d521128b852980cecde501de02d',1,'main.cpp']]]
];
