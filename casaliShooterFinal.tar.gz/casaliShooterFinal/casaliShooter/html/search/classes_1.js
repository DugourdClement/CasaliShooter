var searchData=
[
  ['enemy',['enemy',['../structenemy.html',1,'']]],
  ['enemystruct',['enemyStruct',['../structenemy_struct.html',1,'']]]
];
