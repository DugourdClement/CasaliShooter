#ifndef YAML_H
#define YAML_H

#include <vector>

std::vector<unsigned> vecParam (const std::string &);

#endif // YAML_H
